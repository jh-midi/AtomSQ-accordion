installer un créateur de port virtuel 
puis créer un port avec le nom : diato

You have to create a virtual MIDI port named diato

this application do the job :

https://www.tobias-erichsen.de/software/loopmidi.html

atomSQ.exe => all rows to channel 1
atomSQ2.exe => row1= channel 1
               row2= channel 2

run the atom.bat from windows explorer or the exe from CMD terminal.

and also an ATOM SQ is mandatory :)

